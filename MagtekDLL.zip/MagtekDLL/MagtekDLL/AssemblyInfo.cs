using System;
using ObjCRuntime;

//[assembly: LinkWith ("libMTSCRA.a", LinkTarget.Simulator | LinkTarget.ArmV6 | LinkTarget.ArmV7, Frameworks="SystemFrameworks",ForceLoad = true)]
[assembly: LinkWith ("libMTSCRA.a", LinkTarget.Simulator | LinkTarget.ArmV6 | LinkTarget.ArmV7 | LinkTarget.Thumb, "-lc++",SmartLink=true, ForceLoad = true, IsCxx = true)]
